1. Logo visible de micro bollos en pdf

2. Permitir firma Digital que en este momento no lo permite

3. Agregar cuit de micro bollos group que quede fijo

4. Agregar nro de siniestro en datos de cliente q debe quedar asociado a cada auto particular del cliente (el cliente puede tener muchos autos y cada uno tiene su propio nro de seguro) 

5. Permitir seleccionar nro sucursal para q tenga nro presupuesto y se pueda guardar

6. Agregar info de contacto (José heredia 351 652-1795 Federico heredia 351 372-0630) 

7. Agregar, para que se vea en el pdf de presupuesto, a que corresponde cada cosa. Por ejemplo, si agregamos repuestos, en el pdf debería decir [REPUESTO] Espejo izq. Si se agrega un cambio de pieza debería decir algo por ej [SERVICIO] Espejo Izq - cambio de pieza

8. Agregar a qué queremos que tome el iva. Ejemplo: abajo permite seleccionar cuánto iva, si 21,20,etc... Lo q hay que agregar es a que queremos que tome iva, es decir, no sólo porcentaje, sino si toma a todo(por defecto si) pero en algunos casos quizá no queremos que iva afecte a repuestos, entonces desmarcamos y seguimos. Que sea en chiquito debajo de todo, estilo menú desplegable

9. Mejorar el responsive para usar en celu

10. En compu verificar que el modal se abra de forma correcta e intuitiva, evitar q se abra arriba de todo y haya q subir, daña la experiencia de usuario

11. Agregar un boton para q el usuario pueda descargar el presupuesto enviar por mail o wsp al numero del cliente, agregale los botones para cada usuario para que se mande el mensajito con el presupuesto adjunto.


# Quiero que revises toda la tecnologia backend echa con js para que funcione que yo mismo aplique aca y para garantizar persistencia voy a usar Turso para la base de datos. Necesito que organices y dejes todo trabajado para que funcione correctamente.

# Importante: aclarar que revises los tonos los colores y todo lo que tenga que ver con la estetica del sistema para que sea visualmente agradable y agradable de usar. Todas las funcionalidades deben quedar agradable de usar.

# Revisa los modales las firmas los pdfs y todo lo que sea entregable que el usuario pueda descargar y que funcione correctamente.